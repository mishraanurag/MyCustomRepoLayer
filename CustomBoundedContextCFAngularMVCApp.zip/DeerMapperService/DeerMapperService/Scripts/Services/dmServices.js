﻿angular.module('myApp').factory("dmService", function ($http, $q) {
    return {
        getIDs: function () {
            // Get the deferred object
            //var deferred = $q.defer();
            //// Initiates the AJAX call
            //$http({ method: 'GET', url: '/events/GetTalkDetails' }).success(deferred.resolve).error(deferred.reject);
            //// Returns the promise - Contains result once request completes
            //return deferred.promise;
        },
        getRoles: function () {
            // Get the deferred object
            //var deferred = $q.defer();
            //// Initiates the AJAX call
            //$http({ method: 'GET', url: '/events/GetSpeakerDetails' }).success(deferred.resolve).error(deferred.reject);
            //// Returns the promise - Contains result once request completes
            //return deferred.promise;
        },
        getRoleIdByName: function (name) {
            // Get the deferred object
        //var deferred = $q.defer();
        //    // Initiates the AJAX call
        //$http({ method: 'GET', url: '/events/GetSpeakerDetails' }).success(deferred.resolve).error(deferred.reject);
        //    // Returns the promise - Contains result once request completes
        //return deferred.promise;
        },
        posttogettoken : function(data)
        {
            $http.post('/users/authentication',
        JSON.stringify(data),
            {
            headers: {
                'Content-Type': 'application/json'
            }
            }).success(function (data) {
                //$scope.person = data;
                var returntoken = JSON.parse(data);
                alert(returntoken.username + returntoken.access_token);
            })
            .error(function (data, status, header, config) {
                var returnerrdata = JSON.parse(data);
                alert("Data: " + parse.JSON(data) +
                    "<hr />status: " + status +
                    "<hr />headers: " + header +
                    "<hr />config: " + config);
            });
       }

    }
});