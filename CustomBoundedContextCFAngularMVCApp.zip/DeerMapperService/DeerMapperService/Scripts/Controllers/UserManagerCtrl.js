﻿//(function () {
//    'use strict';

//    angular
//        .module('app')
//        .controller('UserManagerCtrl', UserManagerCtrl);

//    UserManagerCtrl.$inject = ['$location']; 

//    function UserManagerCtrl($location) {
//        /* jshint validthis:true */
//        var vm = this;
//        vm.title = 'UserManagerCtrl';

//        activate();

//        function activate() { }
//    }
//})();
//angular.module('myApp').controller('UserManagerCtrl', function ($scope) {
angular.module('myApp').controller('UserManagerCtrl', function ($scope, dmService) {
    $scope.isCollapsed = false;
    $scope.isCollapsedLogin = false;
    $scope.AcctNo = "112233445566";
    $scope.AcctName = "Anurag";
    $scope.Addr = "1644 W Main Ave De Pere WI 54115";
    $scope.Pwd = "manual77";
    $scope.Status = true;
    $scope.LoginAcctNbr = "LoginUName";
    $scope.LoginPwd = "LoginPassword";
    $scope.Login = function () {
        var data = {
                        username: $scope.LoginAcctNbr,
                        password: $scope.LoginPwd,
                        grant_type: "password"
                    };
   
        dmService.posttogettoken(data);
       
        };
    /*$scope.Register = function () {
        //alert("Hello World! - Registration Form");
    };*/
});