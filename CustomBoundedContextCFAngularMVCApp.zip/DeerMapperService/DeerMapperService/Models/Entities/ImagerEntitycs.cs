﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeerMapperService.Models.Entities
{
    public class ImagerEntity : AuditableEntity
    {
        public string ImagerRegNum { get; set; }
        public string ImagerName { get; set; }
        public string GatewayRegNum { get; set; }
        public string RelayRegNum { get; set; }
        public virtual GatewayEntity Gateway { get; set; }
        public virtual RelayEntity Relay { get; set; }
    }    
 }

