﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeerMapperService.Models.Entities
{
  public class UserAccountEntity: AuditableEntity
    {
        public string AccountNbr { get; set; }
        public string AccountName { get; set; }
        public string AccAddr { get; set; }
        public string Status { get; set; }
        public string RoleId { get; set; }
        public string GatewayRegNum { get; set; }
        public string SuperId { get; set; }
        public virtual RoleEntity Role { get; set; }
        public virtual GatewayEntity Gateway { get; set; }
        public virtual UserAccountEntity Super { get; set; }

    }
}
