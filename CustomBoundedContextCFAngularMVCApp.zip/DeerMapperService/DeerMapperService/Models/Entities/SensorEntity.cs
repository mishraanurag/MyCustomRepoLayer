﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeerMapperService.Models.Entities
{
    public class SensorEntity : AuditableEntity
    {
        public string SensorRegNum { get; set; }
        public string SensorName { get; set; }
        public string GatewayRegNum { get; set; }
        public string RelayRegNum { get; set; }
        public virtual GatewayEntity Gateway { get; set; }
        public virtual RelayEntity Relay { get; set; }
    }        
}
