﻿using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using DeerMapperService.Models.Entities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeerMapperService.Models.Mappings
{
    public class RelayMap : EntityTypeConfiguration<RelayEntity>
    {
        public RelayMap()
        {
            HasKey(rl => rl.RelayRegNum);
            Property(rl => rl.RelayRegNum).HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);
            Property(rl => rl.RelayName).IsRequired();
            HasRequired<GatewayEntity>(g => g.Gateway)
            .WithMany(g => g.Relays)
            .HasForeignKey(f => f.GatewayRegNum);
            ToTable("Relays");
        }
    }
}
