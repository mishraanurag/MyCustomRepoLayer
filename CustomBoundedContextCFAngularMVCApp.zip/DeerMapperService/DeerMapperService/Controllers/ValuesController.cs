﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace DeerMapperService.Controllers
{
    public class ValuesController : ApiController
    {

        public ValuesController()
        {

        }
        // GET api/values
        public async Task<List<string>> Get()
        {
            List<string> abc = new List<string>();
            await Task.Run(async() =>
               {
                    abc = await GetStr();
               });
            return abc;
        }

        // GET api/values/5
        public string Get(int id)
        {
            return "value";
        }

        // POST api/values
        public void Post([FromBody]string value)
        {
        }

        // PUT api/values/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/values/5
        public void Delete(int id)
        {
        }
        private async Task<List<string>> GetStr()
        {
            var test = new List<string>();

            await Task.Run(() =>
            {
                //var test = new List<string>();
                //var abc = new List<string>();
                test.Add("Value1");
                test.Add("Value2");
            });
            return test;
        }


     }

   
}
