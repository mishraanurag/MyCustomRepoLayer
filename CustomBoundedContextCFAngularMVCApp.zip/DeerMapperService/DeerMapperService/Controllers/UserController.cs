﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using DeerMapperService.Models.Entities;
using DeerMapperService.Models.ValueObjects;
using Newtonsoft.Json.Linq;
using System.Threading.Tasks;
using System.Net.Http.Headers;
using System.Web;
using System.Configuration;

namespace DeerMapperService.Controllers
{
   // [RoutePrefix("user")]
    public class UserController : ApiController
    {
        // GET api/<controller>
        [Authorize(Roles ="Tiger")]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/<controller>/5
        public string Get(int id)
        {
            return "value";
        }

        [Route("users/{authenticate}")]
        [HttpPost]
        public async Task<oAuthTicket> Post(LoginAuth value)
        {
            string xReturn = "" ;

            if (value == null)
            {
                xReturn = "Invalid Credentials";
               // return xReturn;
            }
            else
            { 
            await Task.Run(() =>
                        {
                            using (var client = new HttpClient { BaseAddress = new Uri(ConfigurationManager.AppSettings["BaseAddr"]) })
                            {
                            var token = client.PostAsync("Token",
                                new FormUrlEncodedContent(new[]
                                {
            new KeyValuePair<string,string>("grant_type",value.grant_type),
            new KeyValuePair<string,string>("username",value.username),
            new KeyValuePair<string,string>("password",value.password)
                                    })).Result.Content.ReadAsAsync<OAuthToken>().Result;

                                if (token.access_token == null)
                                {
                                    xReturn = "Credentials Validated Failed";
                                }
                                else
                                {
                                    xReturn = token.token_type.ToString().Trim() + " " + token.access_token.ToString();
                                }
                            };

                        });
            }
            oAuthTicket authTicket = new oAuthTicket();
            authTicket.username = value.username;
            authTicket.access_token = xReturn;

            return authTicket;
           // return xReturn;

    }

        // PUT api/<controller>/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/<controller>/5
        public void Delete(int id)
        {
        }
    }
}