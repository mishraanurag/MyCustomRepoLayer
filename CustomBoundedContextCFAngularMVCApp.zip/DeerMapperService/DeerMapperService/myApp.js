﻿(function () {
    'use strict';

    //angular.module('myApp', [
    //    // Angular modules 
    //    'ngRoute'

    //    // Custom modules 

    //    // 3rd Party Modules
        
    //]);
    //var myApp = angular.module("myApp", ['ngRoute', 'ngAnimate', 'ui.bootstrap'])
    angular.module('myApp', ['ngRoute', 'ngAnimate', 'ui.bootstrap']);
        //.config(function ($routeProvider) {
        //Path - it should be same as href link
        //$routeProvider.when('/RegisterUser', { templateUrl: '/Views/Templates/Talk.html', controller: 'eventController' });
        //$routeProvider.when('/Login', { templateUrl: '/Views/Templates/Speaker.html', controller: 'speakerController' });
   // });
})();