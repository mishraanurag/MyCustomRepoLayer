﻿using Microsoft.Owin;
using Microsoft.Owin.Security.OAuth;
using Owin;
using System;
using System.Web.Http;
using System.Web.Routing;

[assembly: OwinStartupAttribute(typeof(DeerMapperService.Startup))]
namespace DeerMapperService
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);           
            HttpConfiguration config = new HttpConfiguration();
           // WebApiConfig.Register(config);
            
            app.UseWebApi(config);
            app.Use((context, next) =>
    {
        if (context.Request.Path.HasValue && context.Request.Path.Value.ToUpper().Contains("/HELP"))
        {
            return context.Response.WriteAsync("<Html><Body><H1>This feature is disabled for Security purpose</H1></Body></Html>");
        }
        return next.Invoke();
    });

   }
  }
}
