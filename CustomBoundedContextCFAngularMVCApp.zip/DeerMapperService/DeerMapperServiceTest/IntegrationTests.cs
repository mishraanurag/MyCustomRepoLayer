﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using DeerMapperService.Models.Entities;
using DeerMapperService.Models;
using System.Linq;

namespace DeerMapperServiceTest
{
    [TestClass]
    //[DeploymentItem("EntityFramework.SqlServer.dll")]
    public class DeerMapperRepoLayerTest
    {
        [TestMethod]
        public void InserEntity()
        {
            PropertyEntity prop = new PropertyEntity();
            prop.PropertyNum = "33333";
            prop.PropertyName = "TestProp3";
            prop.ZipCode = "08901";
            prop.AddedDate = "01/01/2016";            
            PropertyEntity abc = null;

            UnitOfWork MyUOW = new UnitOfWork();
            var propRepo = MyUOW.Repository<PropertyEntity>();

            propRepo.Insert(prop);
            MyUOW.Save();

            abc = propRepo.GetById("33333");

            MyUOW.Dispose();

            Assert.IsNotNull(abc);           
        }



        [TestMethod]
        public void UpdateEntity()
        {

            UnitOfWork MyUOW = new UnitOfWork();
            var propRepo = MyUOW.Repository<PropertyEntity>();

            var abc = propRepo.GetById("33333");
            abc.PropertyName = "ModifiedTest2";
            abc.ModifiedDate = "08/02/2016";

            MyUOW.Save();

            var xyz = propRepo.GetById("33333");
            MyUOW.Dispose();

            Assert.IsTrue(xyz.PropertyName == "ModifiedTest2");
        }



       [TestMethod]
        public void DeleteEntity()
        {
            UnitOfWork MyUOW = new UnitOfWork();
            var propRepo = MyUOW.Repository<PropertyEntity>();
           
            var abc = propRepo.GetById("33333");

            propRepo.Delete(abc);
            MyUOW.Save();

            var xyz = propRepo.GetById("33333");
            MyUOW.Dispose();

            Assert.IsNull(xyz);

        }
    }
}
