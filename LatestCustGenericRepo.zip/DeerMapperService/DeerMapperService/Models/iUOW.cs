﻿

namespace DeerMapperService.Models
{
    public interface iUOW
    {
    }
}
