﻿using System;
using System.Data.Entity;
using System.Data.Entity.Validation;
using System.Linq;
using DeerMapperService.Models.Entities;
using System.Collections.Generic;

namespace DeerMapperService.Models
{
    public class Repository<T> : iRepository<T> where T : AuditableEntity
    {
        private readonly DomainContext context;
        private IDbSet<T> entities;
        string errorMessage = string.Empty;

        public Repository(DomainContext context)
        {
            this.context = context;
        }

        public virtual T GetById(object id)
        {
            return Entities.Find(id); 
        }

        public virtual void Insert(T entity)
        {
            try
            {
                if (entity == null)
                {
                    throw new ArgumentNullException("entity");
                }
                if (this.entities == null)
                {
                    if (entity != null)
                    {
                        Entities.Add(entity);
                    }
                }
                else
                {
                      Entities.Add(entity);
                }
            }
            catch (DbEntityValidationException dbEx)
            {

                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        errorMessage += string.Format("Property: {0} Error: {1}",
                        validationError.PropertyName, validationError.ErrorMessage) + Environment.NewLine;
                    }
                }
                throw new Exception(errorMessage, dbEx);
            }
        }

        public virtual void Update(T entity)
        {
            try
            {
                if (entity == null)
                {
                    throw new ArgumentNullException("entity");
                }

            }
            catch (DbEntityValidationException dbEx)
            {
                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        errorMessage += Environment.NewLine + string.Format("Property: {0} Error: {1}",
                        validationError.PropertyName, validationError.ErrorMessage);
                    }
                }

                throw new Exception(errorMessage, dbEx);
            }
        }

        public virtual void Delete(T entity)
        {
            try
            {
                if (entity == null)
                {
                    throw new ArgumentNullException("entity");
                }
                var objectState = entity as IObjectState;
                if (objectState != null)
                    objectState.State = ObjectState.Deleted;
                Del(entity);
            }
            catch (DbEntityValidationException dbEx)
            {

                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        errorMessage += Environment.NewLine + string.Format("Property: {0} Error: {1}",
                        validationError.PropertyName, validationError.ErrorMessage);
                    }
                }
                throw new Exception(errorMessage, dbEx);
            }
        }

        private void Del(T entity)
        {
            Entities.Attach(entity);
            Entities.Remove(entity);
        }


        public virtual IList<T> All
        {
            get
            {
                return this.Entities.ToList();
            }
        }


        private IDbSet<T> Entities
        {
            get
            {
                if (entities == null)
                {
                    entities = context.Set<T>();
                }

                return entities;

            }
        }
    }
}
