﻿
using DeerMapperService.Models.Entities;

namespace DeerMapperService.Models
{
    public interface iRepository<TEntity> where TEntity : AuditableEntity
    {

        TEntity GetById(object id);
        void Insert(TEntity entity);
        void Update(TEntity entity);
        void Delete(TEntity entity);      
    }
}
