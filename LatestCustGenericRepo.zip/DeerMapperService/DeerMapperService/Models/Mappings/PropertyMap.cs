﻿using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using DeerMapperService.Models.Entities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeerMapperService.Models.Mappings
{
    public class PropertyMap: EntityTypeConfiguration<PropertyEntity>
    {
        public PropertyMap()
        {
            HasKey(p => p.PropertyNum);
            Property(p => p.PropertyNum).HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);
            Property(p => p.PropertyName).IsRequired();
            Property(p => p.ZipCode).IsRequired();
            ToTable("Property");
        }           
    }
}
