﻿using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using DeerMapperService.Models.Entities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeerMapperService.Models.Mappings
{
    public class GatewayMap : EntityTypeConfiguration<GatewayEntity>
    {
        public GatewayMap()
        {
            HasKey(g => g.GatewayRegNum);
            Property(g => g.GatewayRegNum).HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);
            Property(g => g.Longitude).IsRequired();
            Property(g => g.Latitude).IsRequired();
            HasRequired<PropertyEntity>(p => p.Property)
            .WithMany(g => g.Gateways) //.Map(c => c.MapKey("PropertyNum"));
            .HasForeignKey(f => f.PropertyNum);
            ToTable("Gateways");
        }
    }    
}
