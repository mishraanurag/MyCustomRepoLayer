﻿using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using DeerMapperService.Models.Entities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeerMapperService.Models.Mappings
{
    public class ImagerMap : EntityTypeConfiguration<ImagerEntity>
    {
        public ImagerMap()
        {
            HasKey(i => i.ImagerRegNum);
            Property(i => i.ImagerRegNum).HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);
            Property(i => i.ImagerName).IsRequired();
            HasRequired<GatewayEntity>(g => g.Gateway)
                .WithMany(g => g.Imagers) 
                .HasForeignKey(f => f.GatewayRegNum);
            HasOptional<RelayEntity>(c => c.Relay)
                    .WithMany(rl => rl.Imagers)
                    .HasForeignKey(f => f.RelayRegNum);
            ToTable("Imagers");
        }
    }
}
