﻿using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using DeerMapperService.Models.Entities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeerMapperService.Models.Mappings
{
   public class UserAccountMap : EntityTypeConfiguration<UserAccountEntity>
    {
        public UserAccountMap()
        {
            HasKey(ua => ua.AccountNbr);
            Property(ua => ua.AccountNbr).HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);
            Property(ua => ua.AccountName).IsRequired();
            Property(ua => ua.AccAddr).IsRequired();
            HasRequired<GatewayEntity>(g => g.Gateway)
                .WithMany(g => g.Users)
                .HasForeignKey(f => f.GatewayRegNum);
            HasRequired<RoleEntity>(ur => ur.Role)
                .WithMany(u => u.Users)
                .HasForeignKey(f => f.RoleId);
            HasOptional<UserAccountEntity>(c => c.Super)
                    .WithMany()
                    .HasForeignKey(f => f.SuperId);
            ToTable("UserAccounts");
        }
    }
}
