﻿
using System.Data.Entity;
using DeerMapperService.Models.Entities;

namespace DeerMapperService.Models
{
    public interface IDomainContext
    {
       IDbSet<T> Set<T>() where T : AuditableEntity ;
        int SaveChanges();
        //DbEntityEntry Entry(object o);
        //void Dispose();*/
    }
}
