﻿using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using DeerMapperService.Models.Entities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeerMapperService.Models.Mappings
{
    public class SensorMap : EntityTypeConfiguration<SensorEntity>
    {
        public SensorMap()
        {
            HasKey(s => s.SensorRegNum);
            Property(s => s.SensorRegNum).HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);
            Property(s => s.SensorName).IsRequired();
            HasRequired<GatewayEntity>(g => g.Gateway)
                .WithMany(g => g.Sensors) 
                .HasForeignKey(f => f.GatewayRegNum);
            HasOptional<RelayEntity>(c => c.Relay)
                    .WithMany(rl => rl.Sensors)
                    .HasForeignKey(f => f.RelayRegNum);
            ToTable("Sensors");
        }
    }
}
