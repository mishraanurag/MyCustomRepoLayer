﻿
using DeerMapperService.Models.Entities;

namespace DeerMapperService.Models
{
    public interface iRepository<TEntity> where TEntity : AuditableEntity
    {

        TEntity GetById(object id);
        void Insert(TEntity entity);
        void Update(TEntity entity);
        void Delete(TEntity entity);
       // IQueryable<TEntity> All();
       // IDbSet<TEntity> Entities();

       /* TEntity FindById(object id);
        void InsertGraph(TEntity entity);
        void Update(TEntity entity);
        void Delete(object id);
        void Delete(TEntity entity);
        void Insert(TEntity entity);*/
       //RepositoryQuery<TEntity> Query();
    }
}
