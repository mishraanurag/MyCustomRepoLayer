﻿using System;
using System.Data.Entity;
using System.Data.Entity.Validation;
using System.Linq;
using DeerMapperService.Models.Entities;


namespace DeerMapperService.Models
{
    public class Repository<T> : iRepository<T> where T : AuditableEntity
    {
        private readonly DomainContext context;
        private IDbSet<T> entities;
        string errorMessage = string.Empty;

        public Repository(DomainContext context)
        {
            this.context = context;
        }

        public virtual T GetById(object id)
        {
            return Entities.Find(id); // this.entities.Find(id);
        }

        public void Insert(T entity)
        {
            try
            {
                if (entity == null)
                {
                    throw new ArgumentNullException("entity");
                }
                //this.Entities.Add(entity);
                Entities.Attach(entity);
                //this.context.SaveChanges();
            }
            catch (DbEntityValidationException dbEx)
            {

                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        errorMessage += string.Format("Property: {0} Error: {1}",
                        validationError.PropertyName, validationError.ErrorMessage) + Environment.NewLine;
                    }
                }
                throw new Exception(errorMessage, dbEx);
            }
        }

        public void Update(T entity)
        {
            try
            {
                if (entity == null)
                {
                    throw new ArgumentNullException("entity");
                }
                Entities.Attach(entity);
                //this.context.SaveChanges();
            }
            catch (DbEntityValidationException dbEx)
            {
                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        errorMessage += Environment.NewLine + string.Format("Property: {0} Error: {1}",
                        validationError.PropertyName, validationError.ErrorMessage);
                    }
                }

                throw new Exception(errorMessage, dbEx);
            }
        }

        public void Delete(T entity)
        {
            try
            {
                if (entity == null)
                {
                    throw new ArgumentNullException("entity");
                }

                var entObj = Entities.Find(entity);
                var objectState = entObj as IObjectState;
                if (objectState != null)
                    objectState.State = ObjectState.Deleted;
                Del(entity);

                //this.Entities.Remove(entity);
                //this.context.SaveChanges();
            }
            catch (DbEntityValidationException dbEx)
            {

                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        errorMessage += Environment.NewLine + string.Format("Property: {0} Error: {1}",
                        validationError.PropertyName, validationError.ErrorMessage);
                    }
                }
                throw new Exception(errorMessage, dbEx);
            }
        }

        private void Del(T entity)
        {
            Entities.Attach(entity);
            Entities.Remove(entity);
        }


        public virtual IQueryable<T> All
        {
            get
            {
                return this.entities;
            }
        }

        private IDbSet<T> Entities
        {
            get
            {
                if (entities == null)
                {
                    entities = context.Set<T>();
                }
                return entities;
            }
        }
    }
}
