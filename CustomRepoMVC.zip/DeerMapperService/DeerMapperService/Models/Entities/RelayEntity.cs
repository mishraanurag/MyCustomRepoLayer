﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeerMapperService.Models.Entities
{
    public class RelayEntity: AuditableEntity
    {
        public string RelayRegNum { get; set; }
        public string RelayName { get; set; }
        public string GatewayRegNum { get; set; }
        public virtual ICollection<ImagerEntity> Imagers { get; set; }
        public virtual ICollection<SensorEntity> Sensors { get; set; }
        public virtual GatewayEntity Gateway { get; set; }
    }
}
