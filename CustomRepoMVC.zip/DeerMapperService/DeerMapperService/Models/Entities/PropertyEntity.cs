﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeerMapperService.Models.Entities
{
    public class PropertyEntity: AuditableEntity 
    {
        public string PropertyNum { get; set; }
        public string PropertyName { get; set; }
        public string ZipCode { get; set; }
        public virtual ICollection<GatewayEntity> Gateways { get; set; }
    }
}
