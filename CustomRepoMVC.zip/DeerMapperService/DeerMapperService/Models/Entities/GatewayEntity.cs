﻿using System.Collections.Generic;

namespace DeerMapperService.Models.Entities
{
    public class GatewayEntity: AuditableEntity
    {
        public string GatewayRegNum { get; set; }
        public string GatewayName { get; set; }
        public string Longitude { get; set; }
        public string Latitude { get; set; }
        public string PropertyNum { get; set; }
        public virtual PropertyEntity Property { get; set; }
        public virtual ICollection<ImagerEntity> Imagers { get; set; }
        public virtual ICollection<SensorEntity> Sensors { get; set; }
        public virtual ICollection<RelayEntity> Relays { get; set; }
        public virtual ICollection<UserAccountEntity> Users { get; set; }
    }
}